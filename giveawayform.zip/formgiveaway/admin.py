from django.contrib import admin
from formgiveaway.models import Formmodel

# Register your models here.
admin.site.register(Formmodel)
