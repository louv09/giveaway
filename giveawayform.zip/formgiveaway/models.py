from django.db import models
from django.core.validators import RegexValidator


# Create your models here.
class Formmodel(models.Model):
    full_name = models.CharField(max_length=200)
    phoneNumberRegex = RegexValidator(regex = r"^\+?1?\d{10,13}$")
    phoneNumber = models.CharField(validators = [phoneNumberRegex], max_length = 13, unique = True)
    mail = models.EmailField(max_length=200, unique=True)
    country = models.CharField(max_length=100)
    city = models.CharField(max_length=100)
    instagram_id = models.CharField(max_length=100, unique=True)

    def name(self):
        return self.full_name.capitalize()

    def __str__(self):
        return self.name()