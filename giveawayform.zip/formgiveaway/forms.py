from django import forms
from formgiveaway.models import Formmodel

class MyForm(forms.ModelForm):
    class Meta:
        model = Formmodel
        fields = "__all__"
        labels = {
            'full_name' : 'Full Name',
            'phoneNumber' : 'Phone number',
            'mail' : 'Gmail id',
            'instagram_id' : 'Instagram id'
        }
        error_messages = {
            'mail' : {
                'required' : 'Please enter your Gmail id',
                'unique' : 'This Gmail id is alerady in use',
                'invalid' : 'Please enter a valid Gmail id'
            },

            'instagram_id' : {
                'required' : 'Please enter your instagram id',
                'unique' : 'This instagram id is alerady in use',
                'invalid' : 'Please enter a valid instagram id'
            },
            'phoneNumber' : {
                'required' : 'Please enter a number',
                'unique' : 'This number is alerady in use',
                'invalid' : 'Please enter a 10 digit number'
            }
        }

