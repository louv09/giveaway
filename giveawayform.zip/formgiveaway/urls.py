from django.urls import path
from . import views


urlpatterns = [
    path("", views.Formview.as_view()),
    path("thank-you", views.thankyou),
]