from django.forms.models import modelform_factory
from django.shortcuts import render
from django.views.generic import CreateView
from formgiveaway.models import Formmodel
from formgiveaway.forms import MyForm

# Create your views here.
class Formview(CreateView):
    template_name = "formgiveaway/gform.html"
    model = Formmodel
    form_class = MyForm 
    success_url = "/thank-you"

def thankyou(request):
    return render(request, "formgiveaway/thank.html")